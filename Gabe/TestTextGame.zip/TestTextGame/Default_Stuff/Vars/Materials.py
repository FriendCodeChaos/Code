class Materails:
    Wood = 0
    class mine:
        Stone = 0
        Salt = 0
        Coal = 0
        Copper = 0
        Iron = 0
        Gold = 0
        Diamond = 0
        Platinum= 0
        class percent:
            Stone = 90/100
            Salt = 0.5/100
            Coal = 5/100
            Copper = 2/100
            Iron = 1.5/100
            Gold = 0.6/100
            Diamond = 0.3/100
            Platinum = 0.1/100
