class Jobs:
    class Other:
        Ammount = 10
        BornAdd, DeathAdd = 20, 1
    class Park:
        Ammount = 10
        BornAdd, DeathAdd = 20, 1
    class School:
        Ammount = 10
        BornAdd, DeathAdd = 5, 1
    class Farm:
        Ammount = 10
        BornAdd, DeathAdd = 15, 2
    class CraftsmanTech:
        Ammount = 10
        BornAdd, DeathAdd = 10, 3
    class CraftsmanMagic:
        Ammount = 10
        BornAdd, DeathAdd = 10, 9
    class ScienceTech:
        Ammount = 10
        BornAdd, DeathAdd = 10, 5
    class ScienceMagic:
        Ammount = 10
        BornAdd, DeathAdd = 10, 15
    class Lumberjack:
        Ammount = 10
        BornAdd, DeathAdd = 2, 5
    class Miner:
        Ammount = 10
        BornAdd, DeathAdd = 2, 10
    class none:
        Ammount = 0
        BornAdd, DeathAdd = 20, 2
