class people:
    ammount = 1000
    born = 11/100
    death = 2/100
