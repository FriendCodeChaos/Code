SaveNamePath = ""
ext = "json"
ModName = "TestMod"
ModDes = "Just a test mod"