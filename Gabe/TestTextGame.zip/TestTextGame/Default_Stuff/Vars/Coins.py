class Coins:
    Lesser = 0
    Copper = 0
    Bronze = 10
    Iron = 0
    Gold = 0
    Diamond = 0
    Platinum= 0
